let timeout = null;
let lastUrl = location.href;

function containsLatex(element) {
  const text = element.innerText || "";
  return (
    text.includes("\\(") ||
    text.includes("\\[") ||
    text.includes("$$") ||
    /(^|[^\\])\$[^$]+\$/.test(text)
  );
}

async function renderLatex() {
  const mailBodies = document.querySelectorAll("div.a3s");

  for (const body of mailBodies) {
    if (!containsLatex(body)) continue;

    if (!window.MathJax || !window.MathJax.typesetPromise) {
      console.error("MathJax pas chargé");
      continue;
    }

    try {
      if (window.MathJax.typesetClear) {
        window.MathJax.typesetClear([body]);
      }

      await window.MathJax.typesetPromise([body]);

      console.log("LaTeX rendu");
    } catch (err) {
      console.error("Erreur MathJax :", err);
    }
  }
}

function scheduleRender() {
  clearTimeout(timeout);
  timeout = setTimeout(renderLatex, 800);
}

const observer = new MutationObserver(() => {
  scheduleRender();
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    console.log("Changement de mail détecté");
    scheduleRender();
    setTimeout(renderLatex, 1500);
  }
}, 500);

setTimeout(renderLatex, 2000);
