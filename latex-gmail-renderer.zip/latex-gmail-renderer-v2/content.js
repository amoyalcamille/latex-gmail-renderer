let timeout = null;
let lastUrl = location.href;

function containsLatexText(text) {
  return (
    text.includes("\\(") ||
    text.includes("\\[") ||
    text.includes("$$") ||
    /(^|[^\\])\$[^$]+\$/.test(text)
  );
}

function containsLatex(element) {
  return containsLatexText(element.innerText || "");
}

async function renderLatexInElement(element) {
  if (!window.MathJax || !window.MathJax.typesetPromise) {
    console.error("MathJax pas chargé");
    return;
  }

  try {
    if (window.MathJax.typesetClear) {
      window.MathJax.typesetClear([element]);
    }

    await window.MathJax.typesetPromise([element]);
  } catch (err) {
    console.error("Erreur MathJax :", err);
  }
}

async function renderReceivedMails() {
  const mailBodies = document.querySelectorAll("div.a3s");

  for (const body of mailBodies) {
    if (!containsLatex(body)) continue;
    await renderLatexInElement(body);
  }
}

function findComposeBodies() {
  return document.querySelectorAll(
    'div[aria-label="Corps du message"], div[aria-label="Message Body"], div[role="textbox"][contenteditable="true"]'
  );
}

function getOrCreatePreview(composeBody) {
  const composeBox = composeBody.closest("div[role='dialog']") || composeBody.parentElement;

  let preview = composeBox.querySelector(".gmail-latex-preview");

  if (!preview) {
    preview = document.createElement("div");
    preview.className = "gmail-latex-preview";

    preview.style.border = "1px solid #dadce0";
    preview.style.borderRadius = "8px";
    preview.style.padding = "10px";
    preview.style.marginTop = "8px";
    preview.style.background = "#fafafa";
    preview.style.fontSize = "14px";
    preview.style.color = "#202124";

    const title = document.createElement("div");
    title.textContent = "Prévisualisation LaTeX";
    title.style.fontWeight = "bold";
    title.style.marginBottom = "6px";

    const content = document.createElement("div");
    content.className = "gmail-latex-preview-content";

    preview.appendChild(title);
    preview.appendChild(content);

    composeBody.insertAdjacentElement("afterend", preview);
  }

  return preview.querySelector(".gmail-latex-preview-content");
}

async function updateComposePreview(composeBody) {
  const text = composeBody.innerText || "";
  const previewContent = getOrCreatePreview(composeBody);

  if (!containsLatexText(text)) {
    previewContent.innerText = "Aucune formule LaTeX détectée.";
    return;
  }

  previewContent.textContent = text;

  await renderLatexInElement(previewContent);
}

function setupComposePreview() {
  const composeBodies = findComposeBodies();

  composeBodies.forEach(composeBody => {
    if (composeBody.dataset.latexPreviewReady === "true") return;

    composeBody.dataset.latexPreviewReady = "true";

    let composeTimeout = null;

    composeBody.addEventListener("input", () => {
      clearTimeout(composeTimeout);
      composeTimeout = setTimeout(() => {
        updateComposePreview(composeBody);
      }, 300);
    });

    updateComposePreview(composeBody);
  });
}

function scheduleRender() {
  clearTimeout(timeout);
  timeout = setTimeout(() => {
    renderReceivedMails();
    setupComposePreview();
  }, 800);
}

const observer = new MutationObserver(() => {
  scheduleRender();
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    scheduleRender();
    setTimeout(() => {
      renderReceivedMails();
      setupComposePreview();
    }, 1500);
  }
}, 500);

setTimeout(() => {
  renderReceivedMails();
  setupComposePreview();
}, 2000);
