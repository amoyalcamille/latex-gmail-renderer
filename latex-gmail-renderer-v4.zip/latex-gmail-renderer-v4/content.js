let timeout = null;
let lastUrl = location.href;

let renderMailsEnabled = true;
let previewEnabled = true;

function containsLatexText(text) {
  return (
    text.includes("\\(") ||
    text.includes("\\[") ||
    text.includes("$$") ||
    /(^|[^\\])\$[^$]+\$/.test(text)
  );
}

function containsLatex(element) {
  return containsLatexText(element.innerText || "");
}

async function renderLatexInElement(element) {
  if (!window.MathJax || !window.MathJax.typesetPromise) return;

  try {
    if (window.MathJax.typesetClear) {
      window.MathJax.typesetClear([element]);
    }

    await window.MathJax.typesetPromise([element]);

    element.querySelectorAll("mjx-container").forEach(el => {
      el.style.maxWidth = "100%";
      el.style.boxSizing = "border-box";
    });

    element.querySelectorAll("mjx-container[display='true']").forEach(el => {
      el.style.display = "block";
      el.style.overflowX = "auto";
      el.style.overflowY = "hidden";
      el.style.maxWidth = "100%";
      el.style.marginTop = "0.7em";
      el.style.marginBottom = "0.7em";
      el.style.paddingBottom = "2px";
    });
  } catch (err) {
    console.error("Erreur MathJax :", err);
  }
}

async function renderReceivedMails() {
  if (!renderMailsEnabled) return;

  const mailBodies = document.querySelectorAll("div.a3s");

  for (const body of mailBodies) {
    if (!containsLatex(body)) continue;

    if (!body.dataset.originalLatexHtml) {
      body.dataset.originalLatexHtml = body.innerHTML;
    }

    await renderLatexInElement(body);
  }
}

function restoreOriginalMails() {
  const mailBodies = document.querySelectorAll("div.a3s");

  mailBodies.forEach(body => {
    if (body.dataset.originalLatexHtml) {
      body.innerHTML = body.dataset.originalLatexHtml;
      delete body.dataset.originalLatexHtml;
    }
  });
}

function findComposeBodies() {
  return document.querySelectorAll(
    'div[aria-label="Corps du message"], div[aria-label="Message Body"], div[role="textbox"][contenteditable="true"]'
  );
}

function getOrCreatePreview() {
  let preview = document.querySelector("#gmail-latex-floating-preview");

  if (!preview) {
    preview = document.createElement("div");
    preview.id = "gmail-latex-floating-preview";

    preview.style.position = "fixed";
    preview.style.zIndex = "9999999";
    preview.style.display = "none";

    preview.style.maxWidth = "420px";
    preview.style.maxHeight = "220px";
    preview.style.overflow = "auto";

    preview.style.padding = "10px 12px";
    preview.style.border = "1px solid #dadce0";
    preview.style.borderRadius = "12px";
    preview.style.background = "#f8f9fa";
    preview.style.boxShadow = "0 4px 16px rgba(0,0,0,0.18)";

    preview.style.fontSize = "13px";
    preview.style.lineHeight = "1.4";
    preview.style.color = "#202124";

    preview.style.pointerEvents = "none";

    const content = document.createElement("div");
    content.className = "gmail-latex-preview-content";

    content.style.maxWidth = "100%";
    content.style.overflowX = "auto";

    preview.appendChild(content);
    document.body.appendChild(preview);
  }

  return preview.querySelector(".gmail-latex-preview-content");
}

function getCaretCharacterOffsetWithin(element) {
  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0) return null;

  const range = selection.getRangeAt(0);

  if (!element.contains(range.startContainer)) return null;

  const preCaretRange = range.cloneRange();
  preCaretRange.selectNodeContents(element);
  preCaretRange.setEnd(range.startContainer, range.startOffset);

  return preCaretRange.toString().length;
}

function findLatexAroundOffset(text, offset) {
  const patterns = [
    /\\\(([\s\S]*?)\\\)/g,
    /\\\[([\s\S]*?)\\\]/g,
    /\$\$([\s\S]*?)\$\$/g,
    /(^|[^\\])\$((?:\\.|[^$])*)\$/g
  ];

  for (const regex of patterns) {
    let match;

    while ((match = regex.exec(text)) !== null) {
      let start = match.index;
      let end = match.index + match[0].length;

      if (regex.source.startsWith("(^|")) {
        start = match.index + match[1].length;
      }

      if (offset >= start && offset <= end) {
        return text.slice(start, end);
      }
    }
  }

  return null;
}

async function updateComposePreview(composeBody) {
  if (!previewEnabled) return;

  const text = composeBody.innerText || "";
  const offset = getCaretCharacterOffsetWithin(composeBody);

  const previewContent = getOrCreatePreview();
  const previewBox = document.querySelector("#gmail-latex-floating-preview");

  if (offset === null) {
    previewBox.style.display = "none";
    return;
  }

  const latexFragment = findLatexAroundOffset(text, offset);

  if (!latexFragment) {
    previewBox.style.display = "none";
    return;
  }

  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0) {
    previewBox.style.display = "none";
    return;
  }

  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();

  previewBox.style.display = "block";

  let top = rect.bottom + 10;
  let left = rect.left;

  if (left + 420 > window.innerWidth) {
    left = window.innerWidth - 440;
  }

  if (top + 220 > window.innerHeight) {
    top = rect.top - 230;
  }

  previewBox.style.left = Math.max(12, left) + "px";
  previewBox.style.top = Math.max(12, top) + "px";

  previewContent.textContent = latexFragment;

  await renderLatexInElement(previewContent);
}

function setupComposePreview() {
  const composeBodies = findComposeBodies();

  composeBodies.forEach(composeBody => {
    if (composeBody.dataset.latexPreviewReady === "true") return;

    composeBody.dataset.latexPreviewReady = "true";

    let composeTimeout = null;

    composeBody.addEventListener("input", () => {
      if (!previewEnabled) return;

      clearTimeout(composeTimeout);
      composeTimeout = setTimeout(() => {
        updateComposePreview(composeBody);
      }, 200);
    });

    composeBody.addEventListener("keyup", () => {
      if (previewEnabled) updateComposePreview(composeBody);
    });

    composeBody.addEventListener("click", () => {
      if (previewEnabled) updateComposePreview(composeBody);
    });

    composeBody.addEventListener("mouseup", () => {
      if (previewEnabled) updateComposePreview(composeBody);
    });

    composeBody.addEventListener("blur", () => {
      const previewContent = getOrCreatePreview(composeBody);
      const previewBox = previewContent.closest(".gmail-latex-preview");
      previewBox.style.display = "none";
    });
  });
}

function updateAllPreviewVisibility() {
  const previewBox = document.querySelector("#gmail-latex-floating-preview");
  if (previewBox) previewBox.style.display = "none";
}

function createControlPanel() {
  if (document.querySelector("#gmail-latex-panel")) return;

  const panel = document.createElement("div");
  panel.id = "gmail-latex-panel";

  panel.style.position = "fixed";
  panel.style.bottom = "20px";
  panel.style.right = "20px";
  panel.style.zIndex = "999999";
  panel.style.padding = "10px";
  panel.style.borderRadius = "12px";
  panel.style.border = "1px solid #dadce0";
  panel.style.background = "#ffffff";
  panel.style.color = "#202124";
  panel.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
  panel.style.fontSize = "13px";
  panel.style.display = "flex";
  panel.style.flexDirection = "column";
  panel.style.gap = "6px";

  const title = document.createElement("div");
  title.textContent = "LaTeX Gmail";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "4px";

  const mailButton = document.createElement("button");
  const previewButton = document.createElement("button");

  function refreshButtons() {
    mailButton.textContent = renderMailsEnabled
      ? "Lecture mails : ON"
      : "Lecture mails : OFF";

    previewButton.textContent = previewEnabled
      ? "Preview écriture : ON"
      : "Preview écriture : OFF";

    mailButton.style.opacity = renderMailsEnabled ? "1" : "0.5";
    previewButton.style.opacity = previewEnabled ? "1" : "0.5";
  }

  [mailButton, previewButton].forEach(button => {
    button.style.padding = "6px 10px";
    button.style.borderRadius = "18px";
    button.style.border = "1px solid #dadce0";
    button.style.background = "#f8fafd";
    button.style.color = "#202124";
    button.style.cursor = "pointer";
    button.style.fontSize = "13px";
  });

  mailButton.addEventListener("click", () => {
    renderMailsEnabled = !renderMailsEnabled;
    refreshButtons();

    if (renderMailsEnabled) {
      renderReceivedMails();
    } else {
      restoreOriginalMails();
    }
  });

  previewButton.addEventListener("click", () => {
    previewEnabled = !previewEnabled;
    refreshButtons();
    updateAllPreviewVisibility();

    if (previewEnabled) {
      setupComposePreview();
    }
  });

  refreshButtons();

  panel.appendChild(title);
  panel.appendChild(mailButton);
  panel.appendChild(previewButton);

  document.body.appendChild(panel);
}

function scheduleRender() {
  clearTimeout(timeout);

  timeout = setTimeout(() => {
    createControlPanel();

    if (renderMailsEnabled) {
      renderReceivedMails();
    }

    setupComposePreview();
  }, 800);
}

const observer = new MutationObserver(() => {
  scheduleRender();
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;

    scheduleRender();

    setTimeout(() => {
      if (renderMailsEnabled) {
        renderReceivedMails();
      }

      setupComposePreview();
    }, 1500);
  }
}, 500);

setTimeout(() => {
  createControlPanel();

  if (renderMailsEnabled) {
    renderReceivedMails();
  }

  setupComposePreview();
}, 2000);
